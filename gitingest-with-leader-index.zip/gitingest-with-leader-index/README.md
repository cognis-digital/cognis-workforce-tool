# Gitingest with Qdrant Leader Index

Artifacts included:

- `monitoring/qdrant_leader_index.json`: Updated by backend with current leader
- `dashboards/qdrant_leader_dashboard.json`: Grafana dashboard to monitor leader and node flags
